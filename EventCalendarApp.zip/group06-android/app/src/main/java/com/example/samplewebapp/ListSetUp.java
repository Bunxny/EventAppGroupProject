package com.example.samplewebapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ListSetUp extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_set_up);
        //test
    }
}